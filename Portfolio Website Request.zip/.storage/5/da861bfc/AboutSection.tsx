import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Download } from 'lucide-react';

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">About Me</h2>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div className="bg-blue-50 p-1 w-fit rounded-md mb-4">
              <span className="text-blue-700 font-medium text-sm px-2">Hello, I'm</span>
            </div>
            <h3 className="text-4xl font-bold">Your Name</h3>
            <p className="text-gray-600 text-lg">Professional Web Developer & Designer</p>
            <p className="text-gray-600 leading-relaxed">
              I am a passionate web developer and designer with expertise in creating 
              modern, responsive web applications. With a strong background in front-end 
              and back-end technologies, I deliver high-quality solutions that meet client needs.
            </p>

            <div className="pt-4 flex flex-wrap gap-4">
              <Button className="gap-2">
                <Download size={16} />
                Download Resume
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  const contactSection = document.getElementById('contact');
                  if (contactSection) {
                    contactSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Contact Me
              </Button>
            </div>
          </div>
          
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-6">
                {[
                  { label: 'Experience', value: '4+ Years' },
                  { label: 'Projects', value: '20+ Completed' },
                  { label: 'Clients', value: '15+ Happy' },
                  { label: 'Skills', value: '10+ Technologies' },
                ].map((item, i) => (
                  <div key={i} className="text-center p-4 border rounded-lg bg-gray-50">
                    <h4 className="text-lg font-semibold text-blue-600">{item.value}</h4>
                    <p className="text-gray-600 text-sm">{item.label}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-6">
                <h4 className="font-medium mb-2">My Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React', 'Node.js', 'Next.js', 'Tailwind CSS'].map((skill) => (
                    <span 
                      key={skill} 
                      className="px-3 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}