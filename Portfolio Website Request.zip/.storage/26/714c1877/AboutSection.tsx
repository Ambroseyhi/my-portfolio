import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Download } from 'lucide-react';

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-[#0f172a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center text-slate-100">About Me</h2>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <div className="bg-slate-800 p-1 w-fit rounded-md mb-4">
              <span className="px-2 text-sm font-medium text-emerald-400">Hello, I'm</span>
            </div>
            <h3 className="text-4xl font-bold text-slate-100">Bryan Mae Molina</h3>
            <p className="text-lg text-emerald-400">Professional Web Developer & Designer</p>
            <p className="text-slate-400 leading-relaxed">
              I am a passionate web developer and designer with expertise in creating 
              modern, responsive web applications. With a strong background in front-end 
              and back-end technologies, I deliver high-quality solutions that meet client needs.
            </p>

            <div className="pt-4 flex flex-wrap gap-4">
              <Button className="gap-2 bg-emerald-500 hover:bg-emerald-600 text-slate-100">
                <Download size={16} />
                Download Resume
              </Button>
              <Button 
                variant="outline" 
                className="border-emerald-400 text-emerald-400 hover:bg-emerald-400/10"
                onClick={() => {
                  const contactSection = document.getElementById('contact');
                  if (contactSection) {
                    contactSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Contact Me
              </Button>
            </div>
          </div>
          
          <Card className="bg-slate-800 border-slate-700 text-slate-200">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-6">
                {[
                  { label: 'Experience', value: '4+ Years' },
                  { label: 'Projects', value: '20+ Completed' },
                  { label: 'Clients', value: '15+ Happy' },
                  { label: 'Skills', value: '10+ Technologies' },
                ].map((item, i) => (
                  <div key={i} className="text-center p-4 border border-slate-700 rounded-lg bg-slate-900">
                    <h4 className="text-lg font-semibold text-emerald-400">{item.value}</h4>
                    <p className="text-sm text-slate-400">{item.label}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-6">
                <h4 className="font-medium mb-2">My Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React', 'Node.js', 'Next.js', 'Tailwind CSS'].map((skill) => (
                    <span 
                      key={skill} 
                      className="px-3 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}







