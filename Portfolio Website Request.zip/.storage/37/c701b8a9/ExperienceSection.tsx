import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Building, Calendar } from 'lucide-react';

export default function ExperienceSection() {
  const experiences = [
    {
      id: 1,
      position: 'Senior Web Developer',
      company: 'Tech Solutions Inc.',
      period: 'Jan 2021 - Present',
      location: 'San Francisco, CA',
      description: 'Leading the front-end development team in creating responsive and accessible web applications. Implemented performance optimizations that improved page load times by 40%.',
      responsibilities: [
        'Developed and maintained multiple client-facing web applications',
        'Mentored junior developers and conducted code reviews',
        'Implemented CI/CD pipelines for automated testing and deployment',
        'Collaborated with designers to implement responsive UI components',
      ],
      technologies: ['React', 'TypeScript', 'GraphQL', 'AWS'],
    },
    {
      id: 2,
      position: 'Full Stack Developer',
      company: 'Digital Innovations Co.',
      period: 'Mar 2018 - Dec 2020',
      location: 'Boston, MA',
      description: 'Worked on full stack development of web applications using modern JavaScript frameworks and RESTful APIs.',
      responsibilities: [
        'Built RESTful APIs using Node.js and Express',
        'Designed and implemented database schemas using MongoDB and PostgreSQL',
        'Created responsive front-end interfaces with React and Angular',
        'Participated in agile development processes and sprint planning',
      ],
      technologies: ['JavaScript', 'Node.js', 'Express', 'MongoDB', 'React'],
    },
    {
      id: 3,
      position: 'Junior Web Developer',
      company: 'WebCraft Agency',
      period: 'Jun 2016 - Feb 2018',
      location: 'Remote',
      description: 'Developed and maintained websites for various clients across different industries.',
      responsibilities: [
        'Created responsive websites using HTML, CSS, and JavaScript',
        'Implemented designs from Figma and Adobe XD mockups',
        'Managed content using WordPress and custom CMS solutions',
        'Optimized websites for speed and SEO performance',
      ],
      technologies: ['HTML', 'CSS', 'JavaScript', 'WordPress', 'PHP'],
    },
  ];

  return (
    <section id="experience" className="py-20 bg-[#0f172a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center text-slate-100">Work Experience</h2>
        
        <div className="space-y-6 relative">
          {/* Timeline line */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-700 -translate-x-1/2" />
          
          {experiences.map((exp, index) => (
            <div key={exp.id} className="relative">
              {/* Timeline dot */}
              <div className="hidden md:block absolute left-1/2 top-10 w-4 h-4 rounded-full bg-emerald-500 border-4 border-slate-800 -translate-x-1/2 z-10" />
              
              <div className={`md:grid md:grid-cols-2 gap-8 ${index % 2 === 0 ? '' : 'md:rtl'}`}>
                <div className={`md:text-right md:self-center ${index % 2 === 1 ? 'md:order-2 md:text-left' : ''}`}>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-slate-100">{exp.position}</h3>
                    
                    <div className="flex items-center gap-2 text-emerald-400 mt-1 mb-2 md:justify-end">
                      <Building size={16} />
                      <span>{exp.company}</span>
                      {index % 2 === 1 && <div className="hidden md:block"></div>}
                    </div>
                    
                    <div className="flex items-center gap-2 text-slate-400 mb-3 md:justify-end">
                      <Calendar size={16} />
                      <span>{exp.period}</span>
                      <Badge variant="outline" className="border-slate-700 text-slate-300">{exp.location}</Badge>
                    </div>
                    
                    <p className="text-slate-400">{exp.description}</p>
                  </div>
                </div>
                
                <Card className={`${index % 2 === 1 ? 'md:order-1' : ''} bg-slate-800 border-slate-700 text-slate-200`}>
                  <CardContent className="p-6">
                    <h4 className="font-medium mb-3 text-slate-200">Key Responsibilities</h4>
                    <ul className="space-y-2 list-disc pl-5 text-slate-400">
                      {exp.responsibilities.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                    
                    <div className="mt-4">
                      <h4 className="font-medium mb-2 text-slate-200">Technologies Used</h4>
                      <div className="flex flex-wrap gap-1">
                        {exp.technologies.map((tech, i) => (
                          <span 
                            key={i}
                            className="px-2 py-0.5 bg-slate-700 text-emerald-400 rounded-full text-xs font-medium border border-slate-600"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}