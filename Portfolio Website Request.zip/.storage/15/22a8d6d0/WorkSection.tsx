import { Card, CardContent, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ExternalLink, Github } from 'lucide-react';

export default function WorkSection() {
  const projects = [
    {
      id: 1,
      title: 'E-Commerce Website',
      description: 'A fully functional e-commerce platform with product catalog, shopping cart, and payment integration.',
      category: 'web',
      technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      image: 'https://placehold.co/600x400/e9f5ff/1466c9?text=E-Commerce+Project&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
    {
      id: 2,
      title: 'Task Management App',
      description: 'A productivity application for managing tasks, projects and team collaboration.',
      category: 'app',
      technologies: ['React Native', 'Firebase', 'Redux'],
      image: 'https://placehold.co/600x400/f0f8ff/14669e?text=Task+Management+App&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
    {
      id: 3,
      title: 'Portfolio Website',
      description: 'A professional portfolio website showcasing projects and skills.',
      category: 'web',
      technologies: ['HTML', 'CSS', 'JavaScript'],
      image: 'https://placehold.co/600x400/edf6ff/0a4b8f?text=Portfolio+Website&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
    {
      id: 4,
      title: 'Weather Dashboard',
      description: 'A real-time weather application with forecast and location services.',
      category: 'app',
      technologies: ['React', 'OpenWeather API', 'Tailwind CSS'],
      image: 'https://placehold.co/600x400/e5f1ff/1152aa?text=Weather+Dashboard&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
    {
      id: 5,
      title: 'Blog Platform',
      description: 'A content management system for creating and managing blog posts.',
      category: 'web',
      technologies: ['Next.js', 'GraphQL', 'PostgreSQL'],
      image: 'https://placehold.co/600x400/eef7ff/0d377a?text=Blog+Platform&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
    {
      id: 6,
      title: 'Fitness Tracker',
      description: 'An application to track workouts, nutrition, and health metrics.',
      category: 'app',
      technologies: ['Flutter', 'Firebase', 'Chart.js'],
      image: 'https://placehold.co/600x400/f5faff/0a3266?text=Fitness+Tracker&font=raleway',
      demoLink: '#',
      codeLink: '#',
    },
  ];

  return (
    <section id="work" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">My Work</h2>
        
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3 md:grid-cols-4 mb-8">
            <TabsTrigger value="all">All Projects</TabsTrigger>
            <TabsTrigger value="web">Web Development</TabsTrigger>
            <TabsTrigger value="app">App Development</TabsTrigger>
            <TabsTrigger value="design">Design</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="web" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects
                .filter((project) => project.category === 'web')
                .map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
            </div>
          </TabsContent>
          
          <TabsContent value="app" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects
                .filter((project) => project.category === 'app')
                .map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
            </div>
          </TabsContent>
          
          <TabsContent value="design" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects
                .filter((project) => project.category === 'design')
                .map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

interface Project {
  id: number;
  title: string;
  description: string;
  category: string;
  technologies: string[];
  image: string;
  demoLink: string;
  codeLink: string;
}

function ProjectCard({ project }: { project: Project }) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="aspect-video overflow-hidden">
        <img 
          src={project.image} 
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <CardContent className="p-5">
        <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
        <p className="text-gray-600 text-sm mb-3">{project.description}</p>
        <div className="flex flex-wrap gap-1 mb-3">
          {project.technologies.map((tech: string, index: number) => (
            <span key={index} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-xs font-medium">
              {tech}
            </span>
          ))}
        </div>
      </CardContent>
      <CardFooter className="pt-0 px-5 pb-5 flex gap-2">
        <Button size="sm" variant="outline" className="gap-1" asChild>
          <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={14} />
            Live Demo
          </a>
        </Button>
        <Button size="sm" variant="outline" className="gap-1" asChild>
          <a href={project.codeLink} target="_blank" rel="noopener noreferrer">
            <Github size={14} />
            Code
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}