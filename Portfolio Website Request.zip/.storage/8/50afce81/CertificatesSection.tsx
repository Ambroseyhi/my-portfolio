import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { CalendarDays, Award } from 'lucide-react';

export default function CertificatesSection() {
  const certificates = [
    {
      id: 1,
      name: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: 'May 2023',
      credentialId: 'AWS-123456',
      description: 'Validates expertise in designing and deploying scalable systems on AWS.',
      skills: ['AWS', 'Cloud Architecture', 'Security', 'Networking'],
      image: 'https://placehold.co/400x250/e9f5ff/14669e?text=AWS+Certification&font=raleway',
      url: '#',
    },
    {
      id: 2,
      name: 'Meta Front-End Developer',
      issuer: 'Meta (Facebook)',
      date: 'January 2022',
      credentialId: 'META-789012',
      description: 'Comprehensive program covering front-end development skills and best practices.',
      skills: ['React', 'JavaScript', 'HTML/CSS', 'Responsive Design'],
      image: 'https://placehold.co/400x250/eef7ff/0d377a?text=Meta+Developer&font=raleway',
      url: '#',
    },
    {
      id: 3,
      name: 'Google UX Design',
      issuer: 'Google',
      date: 'August 2021',
      credentialId: 'GOOGLE-345678',
      description: 'Professional certification in user experience design fundamentals and practices.',
      skills: ['UI/UX', 'Wireframing', 'Prototyping', 'User Research'],
      image: 'https://placehold.co/400x250/f0f8ff/14669e?text=Google+UX+Design&font=raleway',
      url: '#',
    },
    {
      id: 4,
      name: 'IBM Data Science Professional',
      issuer: 'IBM',
      date: 'March 2021',
      credentialId: 'IBM-901234',
      description: 'Comprehensive training in data science methodologies, tools, and techniques.',
      skills: ['Python', 'Data Analysis', 'Machine Learning', 'Data Visualization'],
      image: 'https://placehold.co/400x250/e5f1ff/1152aa?text=IBM+Data+Science&font=raleway',
      url: '#',
    },
  ];

  return (
    <section id="certificates" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Certificates</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {certificates.map((cert) => (
            <Card key={cert.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <div className="aspect-[4/2.5] overflow-hidden bg-blue-50">
                <img 
                  src={cert.image}
                  alt={cert.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-5">
                <div className="flex items-start gap-3 mb-3">
                  <Award className="text-blue-600 mt-1" size={20} />
                  <div>
                    <h3 className="font-semibold text-lg leading-tight">{cert.name}</h3>
                    <p className="text-gray-600 text-sm">{cert.issuer}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-1 mb-3 text-sm text-gray-500">
                  <CalendarDays size={14} />
                  <span>Issued {cert.date}</span>
                </div>
                
                <p className="text-gray-600 text-sm mb-3">{cert.description}</p>
                
                <div className="flex flex-wrap gap-1 mb-2">
                  {cert.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="font-normal">
                      {skill}
                    </Badge>
                  ))}
                </div>
                
                <div className="mt-3">
                  <a
                    href={cert.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium inline-flex items-center"
                  >
                    View Certificate
                    <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}