import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import AboutSection from '@/components/AboutSection';
import WorkSection from '@/components/WorkSection';
import ExperienceSection from '@/components/ExperienceSection';
import CertificatesSection from '@/components/CertificatesSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { ChevronUp } from 'lucide-react';

export default function WelcomePage() {
  const [activeSection, setActiveSection] = useState('about');
  const [showScrollToTop, setShowScrollToTop] = useState(false);

  // Update active section based on scroll position
  useEffect(() => {
    const sections = ['about', 'work', 'experience', 'certificates', 'contact'];
    
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 300; // Add offset for better UX
      
      // Show or hide scroll to top button
      if (scrollPosition > 500) {
        setShowScrollToTop(true);
      } else {
        setShowScrollToTop(false);
      }
      
      // Find current active section
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetBottom = offsetTop + element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetBottom) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200">
      <Header activeSection={activeSection} setActiveSection={setActiveSection} />
      
      <main className="pt-16"> {/* Add padding top to account for fixed header */}
        <AboutSection />
        <WorkSection />
        <ExperienceSection />
        <CertificatesSection />
        <ContactSection />
      </main>
      
      <Footer />
      
      {/* Scroll to top button */}
      {showScrollToTop && (
        <Button
          size="icon"
          className="fixed bottom-8 right-8 rounded-full shadow-lg bg-emerald-500 hover:bg-emerald-600 z-50"
          onClick={scrollToTop}
          aria-label="Scroll to top"
        >
          <ChevronUp className="h-5 w-5" />
        </Button>
      )}
    </div>
  );
}