import { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Header({ activeSection, setActiveSection }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { name: 'About', section: 'about' },
    { name: 'Work', section: 'work' },
    { name: 'Experience', section: 'experience' },
    { name: 'Certificates', section: 'certificates' },
    { name: 'Contact', section: 'contact' },
  ];

  const handleClick = (section: string) => {
    setActiveSection(section);
    setMobileMenuOpen(false);
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-sm border-b">
      <nav className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            My Portfolio
          </h1>
        </div>
        
        {/* Desktop menu */}
        <div className="hidden md:flex space-x-8">
          {navigation.map((item) => (
            <button
              key={item.name}
              onClick={() => handleClick(item.section)}
              className={`${
                activeSection === item.section
                  ? 'text-blue-600 font-medium'
                  : 'text-gray-600 hover:text-blue-600'
              } transition-colors text-sm`}
            >
              {item.name}
            </button>
          ))}
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b py-2">
          <div className="space-y-1 px-4 py-2">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => handleClick(item.section)}
                className={`${
                  activeSection === item.section
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600'
                } block w-full text-left px-3 py-2 rounded-md text-base font-medium`}
              >
                {item.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}